package com.example.myapp1

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.myapp1.databinding.ActivityCreateAccountBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import model.UserModel


class createAccount : AppCompatActivity() {
    private lateinit var UserName:String
    private lateinit var email: String
    private lateinit var password:String
    private lateinit var auth :FirebaseAuth
    private lateinit var database: DatabaseReference


   private val binding:ActivityCreateAccountBinding by lazy {
       ActivityCreateAccountBinding.inflate(layoutInflater)
   }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        auth= Firebase.auth
        database= Firebase.database.reference




        binding.createAccountButton.setOnClickListener {
            //get text from edit text
            UserName=binding.givenname.text.toString().trim()
            email=binding.givenemail.text.toString().trim()
            password=binding.givenpassword.text.toString().trim()

            if(UserName.isBlank() || email.isBlank() || password.isBlank()){
                Toast.makeText(this,"Please Fill Tis Data",Toast.LENGTH_SHORT).show()
            }else{
                createUserAccount(email,password)
            }
        }
        binding.alreadyHaveAccountButton.setOnClickListener {
            val intent = Intent(this, loginActivity::class.java)
            startActivity(intent)
        }
    }

    private fun createUserAccount(email: String, password: String) {
        auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener { task->
            if (task.isSuccessful){

                Toast.makeText(this,"Account Created",Toast.LENGTH_SHORT).show()
                saveUserData()
                val intent =Intent(this,loginActivity::class.java)
                startActivity(intent)
                finish()
            }
            else{
                Toast.makeText(this,"Account Creation Failed",Toast.LENGTH_SHORT).show()
                Log.d("Account", "createUserAccount: Failure",task.exception)
            }
        }
    }

    //save data in database

    private fun saveUserData() {
        UserName=binding.givenname.text.toString().trim()
        email=binding.givenemail.text.toString().trim()
        password=binding.givenpassword.text.toString().trim()
        val user =UserModel(UserName,email,password)
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        userId?.let {
            database.child("user").child(it).setValue(user)
        }

   }
}









   /*  save data in to database
//    private fun saveUserData() {
//        email = binding.email1.text.toString().trim()
//        password = binding.password1.text.toString().trim()
//        username = binding.name.text.toString().trim()
//        nameOfShop = binding.storename.text.toString().trim()
//        val user = UserModel(username, nameOfShop, email, password)
//        val userId: String = FirebaseAuth.getInstance().currentUser!!.uid
//        //save data in to firbase database
//        database.child("user").child(userId).setValue(user)
//    }*/
