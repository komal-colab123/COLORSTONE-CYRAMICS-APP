package com.example.myapp1

import android.content.Intent
import android.os.Bundle

import androidx.appcompat.app.AppCompatActivity

import com.example.myapp1.databinding.ActivityStartBinding

class startActivity : AppCompatActivity() {
    private val binding: ActivityStartBinding by lazy {
        ActivityStartBinding.inflate(layoutInflater)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(binding.root)
        binding.nextButton.setOnClickListener{
            val intent = Intent(this,createAccount::class.java)
            startActivity(intent)
        }


        }
    }
