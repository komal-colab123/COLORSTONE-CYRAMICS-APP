package com.example.myapp1

import adapter.walladapter
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapp1.databinding.FragmentFaucetsBottomsheetBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment


class faucetsBottomsheetFragment : BottomSheetDialogFragment() {
    private lateinit var binding: FragmentFaucetsBottomsheetBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,

    ): View? {
        binding = FragmentFaucetsBottomsheetBinding.inflate(inflater,container,false)
        binding.buttonBackfaucet.setOnClickListener(){
            dismiss()
        }
        val faucets = listOf(" Single Handle"," Double Handle ","Automatic","Wall Mixer"," Tip-Ton","2 Way Bib Taps","Mordern "," Single Handle "," Double Handle ","Automatic ","Wall Mixer"," Tip-Ton ")
        val faucetPrice = listOf("12","34","56","67","89","10","12","34","56","67","89","10")
        val faucetImages = listOf(
            R.drawable.goldfaucet,
            R.drawable.faucets,
            R.drawable.sinkfaucet,
            R.drawable.blackfaucet,
            R.drawable.classicfauset,
            R.drawable.uniqufaucet,
            R.drawable.homrygropfaucet,
            R.drawable.brasswatterfallfaucet,
            R.drawable.goldwidespreadfauset,
            R.drawable.toiletseatdesignfaucet,
            R.drawable.widespreadfaucet,
            R.drawable.goldfaucet

        )
        val adapter = walladapter(
            ArrayList(faucets),
            ArrayList(faucetPrice),
            ArrayList(faucetImages),requireContext()


        )
        binding.faucetsRecyclerview.layoutManager = LinearLayoutManager(requireContext())
        binding.faucetsRecyclerview.adapter =adapter
        return binding.root
    }

    companion object {

    }
}