package com.example.myapp1

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.myapp1.databinding.ActivityDetailBinding
import fragment.FavoriteFragment
import model.FavoriteItemModel

class DetailActivity : AppCompatActivity() {
    private lateinit var binding : ActivityDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.enquireButton.setOnClickListener {
            val intent = Intent(this, InquiryFormActivity::class.java)
            startActivity(intent)
        }

        binding.addToFavoriteButton.setOnClickListener { // Assuming you have a button with ID addToFavoriteButton
            val itemName = intent.getStringExtra("WallItemName") ?: ""
            val itemPrice = intent.getStringExtra("WallItemPrice") ?: "" // Get item price if available
            val itemImage = intent.getIntExtra("WallItemImage", 0)

            val favoriteItem = FavoriteItemModel(itemName, itemPrice, itemImage)

            val favoriteFragment = supportFragmentManager.findFragmentById(R.id.main) as? FavoriteFragment
            favoriteFragment?.addFavoriteItem(favoriteItem)
        }
    }

}