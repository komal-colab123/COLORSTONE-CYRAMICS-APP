package com.example.myapp1

import adapter.walladapter
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapp1.databinding.FloorTileSectionBinding
import com.example.myapp1.databinding.FragmentBottomSheetFloorBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment


class BottomSheetFloorFragment :BottomSheetDialogFragment() {
    private  lateinit var binding: FragmentBottomSheetFloorBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        binding= FragmentBottomSheetFloorBinding.inflate(inflater,container,false)
        binding.buttonBackfloor.setOnClickListener(){
            dismiss()
        }

        val floortile = listOf("wood Look tiles","Divine Goldtiles","Mordern tiles","Elite Guzzini tiles","wood Look tiles","Divine Goldtiles","Mordern tiles","Elite Guzzini tiles")
        val floorTilePrice = listOf("12","34","56","67","89","10","12","34","56","67","89","10")
        val floorTileImages = listOf(
            R.drawable.floor,
            R.drawable.floordecor,
            R.drawable.designfloor,
            R.drawable.ceramicfloortile,
            R.drawable.divinegoldfloortile,
            R.drawable.eliteguzzinifloor,
            R.drawable.hallwallandfloor,
            R.drawable.woodlookfloor,
            R.drawable.montalcinofloor,
            R.drawable.mordernfloor,
            R.drawable.calacattafloor,
            R.drawable.goldsingularfloorroomtile

        )
        val adapter = walladapter(
            ArrayList(floortile),
            ArrayList(floorTilePrice),
            ArrayList(floorTileImages),requireContext()

        )
        binding.floorRecyclerview.layoutManager = LinearLayoutManager(requireContext())
        binding.floorRecyclerview.adapter =adapter
        return binding.root
    }
    companion object {

    }
}