package com.example.myapp1

import android.icu.text.SimpleDateFormat
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale
import com.example.myapp1.databinding.ActivityInquiryFormBinding
import com.google.firebase.database.FirebaseDatabase
import model.Inquiry
import java.util.Date
import kotlin.text.format

class InquiryFormActivity : AppCompatActivity() {

    private lateinit var binding: ActivityInquiryFormBinding // Assuming you have a binding object

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityInquiryFormBinding.inflate(layoutInflater) // Initialize binding
        setContentView(binding.root)

        binding.submitEnqiryButton.setOnClickListener {
            val inquiry = Inquiry(
                name = binding.nameEnter.text.toString(),
                phone = binding.phoneEnter.text.toString(),
                email = binding.emailEnter.text.toString(),
                date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                address = binding.address.text.toString(),
                message = binding.messageEnter.text.toString(),
                inquiryType = binding.enquiryType.context.toString()

            )

            val databaseRef = FirebaseDatabase.getInstance().getReference("inquiries")
            databaseRef.push().setValue(inquiry)
                .addOnSuccessListener {
                    Toast.makeText(this, "Inquiry submitted successfully", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Failed to submit inquiry", Toast.LENGTH_SHORT).show()
                }
        }
    }
}