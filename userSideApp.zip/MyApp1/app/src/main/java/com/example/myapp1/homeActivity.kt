package com.example.myapp1

import adapter.popularadapter
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class homeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
//        val tileName = listOf("Kitchen","parking","backyard")
//        val preview = listOf("12","30","60","80")
//        val popularTileImages = listOf(R.drawable.kichen_three,R.drawable.parking_one,R.drawable.backyard)
// val adapter = popularadapter(tileName,preview,popularTileImages)


    }
}