package com.example.myapp1


import adapter.walladapter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapp1.databinding.FragmentBottomsheetwallBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment


class BottomsheetwallFragment : BottomSheetDialogFragment(){
    private lateinit var binding : FragmentBottomsheetwallBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        binding= FragmentBottomsheetwallBinding.inflate(inflater,container,false)
        binding.buttonBack.setOnClickListener(){
            dismiss()
        }
        val walltilename = listOf("Ceramic tiles","porcelain tiles","Marble tiles","Mosaic tiles","Cement tiles","vitrified tiles","Ceramic tiles","porcelain tiles","Marble tiles","Mosaic tiles","Cement tiles","vitrified tiles")
        val wallTilePrice = listOf("123","345","567","678","890","103","123","345","567","678","890","103")
        val wallTileImages = listOf(
            R.drawable.cementtiles,
            R.drawable.polished_porcelain_kitchen,
            R.drawable.marbletiles,
            R.drawable.mossictiles,
            R.drawable.cementtiles,
            R.drawable.vitrifiedtiles,
            R.drawable.cementtiles,
            R.drawable.polished_porcelain_kitchen,
            R.drawable.marbletiles,
            R.drawable.mossictiles,
            R.drawable.cementtiles,
            R.drawable.vitrifiedtiles

        )
        val adapter = walladapter(
            ArrayList(walltilename),
            ArrayList(wallTilePrice),
            ArrayList(wallTileImages),requireContext()


        )
        binding.wallRecyclerview.layoutManager = LinearLayoutManager(requireContext())
        binding.wallRecyclerview.adapter =adapter
        return binding.root
    }

    companion object {

    }

}