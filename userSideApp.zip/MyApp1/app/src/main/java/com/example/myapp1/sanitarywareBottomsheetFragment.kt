package com.example.myapp1

import adapter.walladapter
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapp1.databinding.FragmentSanitarywareBottomsheetBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment


class sanitarywareBottomsheetFragment : BottomSheetDialogFragment() {
    private lateinit var binding: FragmentSanitarywareBottomsheetBinding



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        binding = FragmentSanitarywareBottomsheetBinding.inflate(inflater,container,false)
        binding.buttonBacksanitary.setOnClickListener(){
            dismiss()
        }
        val floortile = listOf("Toilets","Urinals","Water Closet","Basins","One Piece Toilet")
        val floorTilePrice = listOf("12","34","56","67","89","10","12","34","56","67","89","10")
        val floorTileImages = listOf(
            R.drawable.wareone,
            R.drawable.waretwo,
            R.drawable.warethree,
            R.drawable.warefour,
            R.drawable.warefive,


        )
        val adapter = walladapter(
            ArrayList(floortile),
            ArrayList(floorTilePrice),
            ArrayList(floorTileImages),requireContext()


        )
        binding.sanitarywareRecyclerview.layoutManager = LinearLayoutManager(requireContext())
        binding.sanitarywareRecyclerview.adapter =adapter
        return binding.root
    }

    companion object {

    }
}