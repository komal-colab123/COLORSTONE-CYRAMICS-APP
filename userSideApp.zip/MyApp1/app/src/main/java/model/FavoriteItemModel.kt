package model

data class FavoriteItemModel(
    val tileName: String,
    val price: String,
    val imageResource: Int,
)
