package model

data class Inquiry(
    val name: String = "",
    val phone: String = "",
    val email: String = "",
    val date: String = "",
    val address:String = "",
    val message: String = "",
    val inquiryType:String=""
)