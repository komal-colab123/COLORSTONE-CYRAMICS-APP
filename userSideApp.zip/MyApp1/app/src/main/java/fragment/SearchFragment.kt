package fragment

import adapter.walladapter
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapp1.R

import com.example.myapp1.databinding.FragmentSearchBinding

class SearchFragment : Fragment() {
    private lateinit var binding: FragmentSearchBinding
    private lateinit var adapter: walladapter

    private val originalProductName = listOf("floor", "wall", "parking")
    private val originalProductPrice = listOf("$100", "$200", "$300")
    private val originalProductImage = listOf(
        R.drawable.cementtiles,
        R.drawable.polished_porcelain_kitchen,
        R.drawable.marbletiles,

    )

    private val filteredProductName = mutableListOf<String>()
    private val filteredProductPrice = mutableListOf<String>()
    private val filteredProductImage = mutableListOf<Int>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View?{
        // Inflate the layout for this fragment
        binding = FragmentSearchBinding.inflate(inflater, container, false)

        adapter = walladapter(filteredProductName, filteredProductPrice, filteredProductImage,requireContext())

        binding.menuRecyler.layoutManager = LinearLayoutManager(requireContext())
        binding.menuRecyler.adapter = adapter

        // Setup search functionality
        setupSearchView()

        // Show all products initially
        showAllProducts()

        return binding.root
    }

    private fun showAllProducts() {
        filteredProductName.clear()
        filteredProductPrice.clear()
        filteredProductImage.clear()

        filteredProductName.addAll(originalProductName)
        filteredProductPrice.addAll(originalProductPrice)
        filteredProductImage.addAll(originalProductImage)

        adapter.notifyDataSetChanged()
    }

    private fun setupSearchView() {
        binding.searchView.setOnQueryTextListener(object :SearchView.OnQueryTextListener,
            android.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                filterProducts(query)
                return true
            }

            override fun onQueryTextChange(newText: String): Boolean {
                filterProducts(newText)
                return true
            }
        })
    }

    private fun filterProducts(query: String) {
        filteredProductName.clear()
        filteredProductPrice.clear()
        filteredProductImage.clear()

        originalProductName.forEachIndexed { index, tilename ->
            if (tilename.contains(query, ignoreCase = true)) {
                filteredProductName.add(tilename)
                filteredProductPrice.add(originalProductPrice[index])
                filteredProductImage.add(originalProductImage[index])
            }
        }

        adapter.notifyDataSetChanged()
    }
    companion object {

    }
}

