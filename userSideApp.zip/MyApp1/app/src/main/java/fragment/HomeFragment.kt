package fragment

import adapter.popularadapter
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapp1.BottomSheetFloorFragment
import com.example.myapp1.BottomsheetwallFragment
import com.example.myapp1.R
import com.example.myapp1.databinding.FragmentHomeBinding
import com.example.myapp1.databinding.PopularItemsBinding
import com.example.myapp1.faucetsBottomsheetFragment
import com.example.myapp1.sanitarywareBottomsheetFragment
import com.google.android.material.bottomsheet.BottomSheetDialog


class HomeFragment : Fragment() {
    private lateinit var binding:FragmentHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View ? {
        // Inflate the layout for this fragment
        binding =FragmentHomeBinding.inflate(inflater,container,false)

       binding.text.setOnClickListener {
           val bottomSheetDialog=BottomsheetwallFragment()
           bottomSheetDialog.show(parentFragmentManager,"Test")
       }
        binding.faucettext.setOnClickListener {
            val bottomSheetDialog = faucetsBottomsheetFragment()
            bottomSheetDialog.show(parentFragmentManager,"Test")
        }
        binding.floortext.setOnClickListener {
            val bottomSheetDialog=BottomSheetFloorFragment()
            bottomSheetDialog.show(parentFragmentManager,"Test")
        }
        binding.sanitarywaretext.setOnClickListener {
            val bottomSheetDialog=sanitarywareBottomsheetFragment()
            bottomSheetDialog.show(parentFragmentManager,"Test")
        }

        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val tileName = listOf("Kitchen","parking","backyard")
        val preview = listOf("12","30","60","80")
        val popularTileImages = listOf(R.drawable.kichen_three,R.drawable.parking_one,R.drawable.backyard)
        val adapter = popularadapter(tileName,preview,popularTileImages,requireContext())
        binding.recycler.layoutManager =LinearLayoutManager(requireContext())
        binding.recycler.adapter = adapter
    }
    companion object {

                }
}