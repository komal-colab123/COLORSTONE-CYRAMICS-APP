package fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.myapp1.R
import com.example.myapp1.databinding.FragmentProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class ProfileFragment : Fragment() {

    private lateinit var binding: FragmentProfileBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding= FragmentProfileBinding.inflate(inflater, container, false)
        auth = FirebaseAuth.getInstance()
        database = Firebase.database.reference

        binding.button2.setOnClickListener {
            saveInformation()
        }

        return binding.root
    }

    private fun saveInformation() {
        val name = binding.root.findViewById<EditText>(R.id.profileName).text.toString().trim() // Assuming you added IDs to your EditTexts
        val address = binding.root.findViewById<EditText>(R.id.profileAdd).text.toString().trim()
        val email = binding.root.findViewById<EditText>(R.id.profileEmail).text.toString().trim()
        val phone = binding.root.findViewById<EditText>(R.id.profilePhone).text.toString().trim()

        // Validate input if needed

        val userId = auth.currentUser?.uid
        if (userId != null) {
            val userProfile = mapOf(
                "name" to name,
                "address" to address,
                "email" to email,
                "phone" to phone
            )
            database.child("users").child(userId).updateChildren(userProfile)
                .addOnSuccessListener {
                    Toast.makeText(requireContext(), "Information saved", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(requireContext(), "Failed to save information", Toast.LENGTH_SHORT).show()
                }
        } else {
            // Handle case where user is not logged in
            Toast.makeText(requireContext(), "User not logged in", Toast.LENGTH_SHORT).show()
        }
    }
}