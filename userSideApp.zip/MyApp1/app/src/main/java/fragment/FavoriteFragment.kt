package fragment

import adapter.favoriteadapter
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapp1.databinding.FragmentFavoriteBinding
import model.FavoriteItemModel

class FavoriteFragment : Fragment() {
    private lateinit var binding: FragmentFavoriteBinding
    private val favoriteItems = mutableListOf<FavoriteItemModel>() // Initialize as empty list
    private lateinit var favoriteAdapter: favoriteadapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentFavoriteBinding.inflate(inflater, container, false)

        // Initialize adapter here
        favoriteAdapter = favoriteadapter(favoriteItems)
        binding.favoriterecyclerview.layoutManager = LinearLayoutManager(requireContext())
        binding.favoriterecyclerview.adapter = favoriteAdapter

        return binding.root
    }

    fun addFavoriteItem(favoriteItem: FavoriteItemModel) {
        // Check if the item is already in favorites to avoid duplicates
        if (!favoriteItems.contains(favoriteItem)) {
            favoriteItems.add(favoriteItem)
            favoriteAdapter.notifyItemInserted(favoriteItems.size - 1)
        }
    }

    companion object {
        // ...
    }
}