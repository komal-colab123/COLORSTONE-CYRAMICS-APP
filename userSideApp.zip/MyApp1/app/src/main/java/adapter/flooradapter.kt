package adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myapp1.databinding.FloorTileSectionBinding

class flooradapter(private val floorItemsname : MutableList<String>,private  val floorItemPrice :MutableList<String>,private val FloorImages :MutableList<Int>):RecyclerView.Adapter<flooradapter.floorViewHolder>(){


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): floorViewHolder {
        val binding =FloorTileSectionBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return  floorViewHolder(binding)
    }



    override fun onBindViewHolder(holder: floorViewHolder, position: Int) {
        holder.bind(position)
    }

    override fun getItemCount(): Int = floorItemsname.size

    inner class floorViewHolder(private  val binding: FloorTileSectionBinding) :RecyclerView.ViewHolder(binding.root){
        fun bind(position: Int) {
            binding.apply {
                floortilename.text=floorItemsname[position]
                details.text=floorItemPrice[position]
                floorimages.setImageResource(FloorImages[position])
            }

        }

    }

}