package adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myapp1.databinding.FavoriteItemBinding
import model.FavoriteItemModel


class favoriteadapter(private val FavoriteItems: MutableList<FavoriteItemModel>) : RecyclerView.Adapter<favoriteadapter.favoriteviewHolder>() {



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): favoriteviewHolder {

        val binding=FavoriteItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return favoriteviewHolder(binding)
    }

    override fun onBindViewHolder(holder: favoriteviewHolder, position: Int) {
        holder.bind(FavoriteItems[position])

    }
    override fun getItemCount(): Int =FavoriteItems.size

    inner class favoriteviewHolder(private  val binding:FavoriteItemBinding) : RecyclerView.ViewHolder(binding.root){
        fun bind(favoriteItem:FavoriteItemModel) {
            binding.apply {

                tilenametype.text=favoriteItem.tileName
                previewimage.text=favoriteItem.price
                addtofavoriteimage.setImageResource(favoriteItem.imageResource)




                deletebutton.setOnClickListener {
                    val itemPosition =adapterPosition
                    if(itemPosition != RecyclerView.NO_POSITION){
                        deleteItem(itemPosition)
                    }


                }
            }

        }

        private fun deleteItem(position: Int) {
            if (position in 0 until FavoriteItems.size) {
                FavoriteItems.removeAt(position)

                notifyItemRemoved(position)
                notifyItemRangeChanged(position, FavoriteItems.size)
            }
        }
    }
}