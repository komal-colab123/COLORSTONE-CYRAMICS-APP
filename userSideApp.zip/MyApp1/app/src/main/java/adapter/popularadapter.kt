package adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapp1.DetailActivity
import com.example.myapp1.databinding.PopularItemsBinding

class popularadapter(private val items:List<String>,private val price:List<String>,private val image:List<Int>,private  val requireContext: Context) : RecyclerView.Adapter<popularadapter.popularviewHolder>() {

    override fun getItemCount(): Int {
       return items.size
    }

    override fun onBindViewHolder(holder: popularviewHolder, position: Int) {
        val item =items[position]
        val images = image[position]
        val price=price[position]
        holder.bind(item,price, images)
        holder.itemView.setOnClickListener{
            val intent= Intent( requireContext, DetailActivity::class.java)
            intent.putExtra("WallItemName",item)
            intent.putExtra("WallItemImage",images)
            requireContext.startActivity(intent)
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): popularviewHolder {
        return popularviewHolder(PopularItemsBinding.inflate(LayoutInflater.from(parent.context),parent,false))
    }
    class popularviewHolder (private val binding:PopularItemsBinding) :RecyclerView.ViewHolder(binding.root) {
        private  val imageView=binding.imageView8

        fun bind(item: String, price: String, images: Int) {
            binding.tilename.text = item
            binding.preview.text= price
            imageView.setImageResource(images)

        }

    }
}