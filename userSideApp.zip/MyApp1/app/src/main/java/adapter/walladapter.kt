package adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myapp1.DetailActivity
import com.example.myapp1.databinding.WallTilesSectionBinding
import fragment.FavoriteFragment
import model.FavoriteItemModel

class walladapter (private val wallItemsNames :MutableList<String>,private val productItemPrice :MutableList<String>,private val wallImage:MutableList<Int>,private val requireContext: Context,private val favoriteFragment: FavoriteFragment?=null): RecyclerView.Adapter<walladapter.wallViewHolder>(){
    private  val itemClickListener : OnClickListener?=null


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): wallViewHolder {
       val binding=WallTilesSectionBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return wallViewHolder(binding)
    }


    override fun onBindViewHolder(holder: wallViewHolder, position: Int) {
        holder.bind(position)
    }

    override fun getItemCount(): Int= wallItemsNames.size

    inner class wallViewHolder(private val binding: WallTilesSectionBinding): RecyclerView.ViewHolder(binding.root) {
        init {
            binding.root.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    itemClickListener?.onItemClick(position)

                    //setonclick listner to open details

                    val intent = Intent(requireContext, DetailActivity::class.java)
                    intent.putExtra("WallItemName", wallItemsNames[position])
                    intent.putExtra("WallItemImage", wallImage[position])
                    requireContext.startActivity(intent)
                }
            }
//            binding.addbutton.setOnClickListener {
//                val position = adapterPosition
//                if (position != RecyclerView.NO_POSITION && favoriteFragment!=null) {
//                    // Add to favorites
//                    val favoriteItem = FavoriteItemModel(
//                        tileName = wallItemsNames[position],
//                        price = productItemPrice[position],
//                        imageResource = wallImage[position]
//                    ) // Create FavoriteItem instance
//                    favoriteFragment.addFavoriteItem(favoriteItem)
//                }
//            }

        }



        fun bind(position: Int) {
       binding.apply {
     tilename.text=wallItemsNames[position]
     details.text=productItemPrice[position]
     wallimages.setImageResource(wallImage[position])
}
        }

    }
    interface OnClickListener{
        fun onItemClick(position: Int)
    }
}