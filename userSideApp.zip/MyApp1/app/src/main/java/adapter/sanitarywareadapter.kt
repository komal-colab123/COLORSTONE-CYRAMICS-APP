package adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myapp1.databinding.SanitarywareSectionBinding

class sanitarywareadapter(private val wareName:MutableList<String>,private val warePrice:MutableList<String>,private val wareImage:MutableList<Int>):RecyclerView.Adapter<sanitarywareadapter.sanitaryViewHolder>() {


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): sanitarywareadapter.sanitaryViewHolder {
        val binding =SanitarywareSectionBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return  sanitaryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: sanitarywareadapter.sanitaryViewHolder, position: Int) {
        holder.bind(position)

    }

    override fun getItemCount(): Int = wareName.size

    inner class sanitaryViewHolder(private val binding: SanitarywareSectionBinding):RecyclerView.ViewHolder(binding.root){
        fun bind(position: Int) {
            binding.apply {
                sanitarywarename.text=wareName[position]
                details.text=warePrice[position]
                sanitarywaresimages.setImageResource(wareImage[position])

            }
        }


    }
}