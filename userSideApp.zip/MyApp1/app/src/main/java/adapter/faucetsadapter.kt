package adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myapp1.databinding.FaucetsSectionBinding


class faucetsadapter(private val faucetItemNames:MutableList<String>, private val faucetItemPrice:MutableList<String>, private val faucetItemImages:MutableList<Int>):RecyclerView.Adapter<faucetsadapter.faucetViewHolder>() {


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): faucetsadapter.faucetViewHolder {
       val binding = FaucetsSectionBinding.inflate(LayoutInflater.from(parent.context),parent,false)
       return faucetViewHolder(binding)
    }

    override fun onBindViewHolder(holder: faucetsadapter.faucetViewHolder, position: Int) {
        holder.bind(position)
    }

    override fun getItemCount(): Int = faucetItemNames.size

    inner class faucetViewHolder(private val binding: FaucetsSectionBinding): RecyclerView.ViewHolder(binding.root){
        fun bind(position: Int) {
            binding.apply {
                texttwofaucet.text=faucetItemPrice[position]
                details.text=faucetItemPrice[position]
                faucetsimages.setImageResource(faucetItemImages[position])

            }
        }

    }

}